jQuery(document).ready(function($){
	/*ComparePrices PopUp*/
	$("#compare_price").on("show", function () {
      $("body").addClass("modal-open");
    }).on("hidden", function () {
      $("body").removeClass("modal-open")
    });
    /*ComparePrices PopUp*/

	});
$(function() {
    $('#filter_search_3').fastLiveFilter('#filter_model');
    
    });